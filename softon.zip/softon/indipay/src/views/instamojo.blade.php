<html>
<head>
    <title>IndiPay</title>
</head>
<body>
    <form method="get" name="redirect" action="{{ $longurl }}">

    </form>
<script language='javascript'>document.redirect.submit();</script>
</body>
</html>

